export default class Action {

    static noOp = 0;
    static moveRight = 1;
    static moveLeft = 2;
    static moveUp = 3;
    static moveDown = 4;
    static suck = 5;

}